package com.jgb.findme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CrearCuentaProveedor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta_proveedor);
    }
}