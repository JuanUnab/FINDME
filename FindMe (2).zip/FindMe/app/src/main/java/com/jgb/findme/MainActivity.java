package com.jgb.findme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void crearcuenta (View view){
       Intent crearcuent= new Intent (MainActivity.this, CrearCuentaActivity.class);
       startActivity(crearcuent);
    }
    public void iniciosesion (View view){
        Intent inicioses= new Intent (MainActivity.this, InicioSesionActivity.class);
        startActivity(inicioses);
    }
}