package com.jgb.findme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CrearCuentaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta);
    }

    public void crearcuentaestudiante (View view){
        Intent crearcuentEst= new Intent (CrearCuentaActivity.this, CrearCuentaEstudiante.class);
        startActivity(crearcuentEst);
    }

    public void crearcuentaproveedor (View view){
        Intent crearcuentpro= new Intent (CrearCuentaActivity.this, CrearCuentaProveedor.class);
        startActivity(crearcuentpro);
    }

}
