package com.jgb.findme.modelo;

public class CrearCuentaProveedor {
}
