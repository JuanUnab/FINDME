package com.jgb.findme.modelo;

public class CrearCuentaEstudiante{
    //declaracion de variables

    private String celular;
    private String ciudad;
    private String correo;
    private String nombre;

    //constructor

public CrearCuentaEstudiante(){

}
//Encapsulación

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    //metodo to string


    @Override
    public String toString() {
        return "CrearCuentaEstudiante{" +
                "celular=" + celular +
                ", ciudad='" + ciudad + '\'' +
                ", correo='" + correo + '\'' +
                ", nombre='" + nombre + '\'' +
                '}';
    }
}


