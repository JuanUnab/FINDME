package com.jgb.findme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CrearCuentaEstudiante extends AppCompatActivity {

    //declaracion de variables
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    private EditText nombre;
    private EditText correo;
    private EditText celular;
    private EditText ciudad;
    private ListView lisV_CrearCuentaEstudiante;
    private final List<com.jgb.findme.modelo.CrearCuentaEstudiante> listCrearCuentaEstudiante = new ArrayList<com.jgb.findme.modelo.CrearCuentaEstudiante>();
    ArrayAdapter<com.jgb.findme.modelo.CrearCuentaEstudiante> arrayAdapterCrearCuentaEstudiante;
    com.jgb.findme.modelo.CrearCuentaEstudiante CrearCuentaEstudianteSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta_estudiante);
        inicializarBD();
        nombre = (EditText) findViewById(R.id.editTextTextPersonName8);
        correo = (EditText) findViewById(R.id.editTextTextEmailAddress);
        celular = (EditText) findViewById(R.id.editTextPhone);
        ciudad = (EditText) findViewById(R.id.editTextTextPersonName9);
        lisV_CrearCuentaEstudiante = (ListView) findViewById(R.id.lvdatosEstudiantes);

        inicializarBD();
        listarDatos();
        lisV_CrearCuentaEstudiante.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                CrearCuentaEstudianteSelected = (com.jgb.findme.modelo.CrearCuentaEstudiante) adapterView.getItemAtPosition(i);
                nombre.setText(CrearCuentaEstudianteSelected.getNombre());
                correo.setText(CrearCuentaEstudianteSelected.getCorreo());
                celular.setText(CrearCuentaEstudianteSelected.getCelular());
                ciudad.setText(CrearCuentaEstudianteSelected.getCiudad());
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menu_estudiante,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void inicializarBD(){
        //llamada a la bd
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance(); //busca el proyecto
        databaseReference = firebaseDatabase.getReference();
        Toast.makeText(this, "Inicializando Base De Datos", Toast.LENGTH_SHORT).show();

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        String nombres = nombre.getText().toString();
        String correos = correo.getText().toString();
        String celulares = celular.getText().toString();
        String ciudades = ciudad.getText().toString();


        switch (item.getItemId()) {

            case R.id.icono_nuevo:
                if (nombres.isEmpty()||(correos.isEmpty()||celulares.isEmpty()||ciudades.isEmpty())){

                    this.validacion();
                }
                else{
                    com.jgb.findme.modelo.CrearCuentaEstudiante objCrearCuentaEstudiante = new com.jgb.findme.modelo.CrearCuentaEstudiante();

                    objCrearCuentaEstudiante.setNombre(nombres);
                    objCrearCuentaEstudiante.setCorreo(correos);
                    objCrearCuentaEstudiante.setCelular(celulares);
                    objCrearCuentaEstudiante.setCiudad(ciudades);

                    //metodos

                    databaseReference.child("ESTUDIANTE").child(objCrearCuentaEstudiante.getCelular()).setValue(objCrearCuentaEstudiante);
                    Toast.makeText(this, "REGISTRO GUARDADO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
                    limpiarcajas();

                }break;
            case R.id.icono_actualizar:
                Toast.makeText(this, "Se presiono Actualizar", Toast.LENGTH_SHORT).show();
                break;

            case R.id.icono_eliminar:
                Toast.makeText(this, "Se presiono eliminar", Toast.LENGTH_SHORT).show();
                break;

            case R.id.icono_home:
                Toast.makeText(this, "Se presiono Regresar ", Toast.LENGTH_SHORT).show();
                Intent icono_home = new Intent(this,MainActivity.class);
                startActivity(icono_home);


                break;

            default:
                break;

        }

        return super.onOptionsItemSelected(item);
    }
public void limpiarcajas(){
        nombre.setText("");
        correo.setText("");
        celular.setText("");
        ciudad.setText("");

}
public void validacion(){
    String nombres = nombre.getText().toString();
    String correos = correo.getText().toString();
    String celulares = celular.getText().toString();
    String ciudades = ciudad.getText().toString();

    if (nombres.isEmpty()) {
        this.nombre.setError("El nombre es requerido");}

    else if (correos.isEmpty()){
        this.correo.setError("El correo es requerido");}

    else if (celulares.isEmpty()){
        this.celular.setError("El celular es requerido");}

    else if (ciudades.isEmpty()){
        this.ciudad.setError("El correo es requerido");}

}
public void listarDatos(){
        databaseReference.child("ESTUDIANTE").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listCrearCuentaEstudiante.clear();
                for (DataSnapshot objSnapshot: snapshot.getChildren());{
                    //com.jgb.findme.modelo.CrearCuentaEstudiante e=objSnapshot.getvalue(com.jgb.findme.modelo.CrearCuentaEstudiante.class);
                    //listCrearCuentaEstudiante.add(e);
                    arrayAdapterCrearCuentaEstudiante = new ArrayAdapter<com.jgb.findme.modelo.CrearCuentaEstudiante>(CrearCuentaEstudiante.this,android.R.layout.simple_list_item_1,listCrearCuentaEstudiante);

               lisV_CrearCuentaEstudiante.setAdapter(arrayAdapterCrearCuentaEstudiante);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


}


}

