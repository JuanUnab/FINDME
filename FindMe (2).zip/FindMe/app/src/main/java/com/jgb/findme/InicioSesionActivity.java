package com.jgb.findme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class InicioSesionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);
    }

    public void crearcuentaestudiante (View view){
        Intent crearcuentEst= new Intent (InicioSesionActivity.this, CrearCuentaEstudiante.class);
        startActivity(crearcuentEst);
    }

    public void crearcuentaproveedor (View view){
        Intent crearcuentpro= new Intent (InicioSesionActivity.this, CrearCuentaProveedor.class);
        startActivity(crearcuentpro);
    }

}